# 光影灯罩 · Litho Lamp Studio

把照片和文字做成可打印的透光浮雕（Lithophane）灯罩，适配 **Bambu Lab LED Lamp Kit 001**（Ø59.5 × 8 mm，5V / 3W）。浏览器本地完成图片预处理、厚度图计算、网格生成与 STL / 3MF 导出，照片不会上传。

## 功能

- **照片环绕**：自动 cover 裁切、旋转、缩放、偏移，亮度 / 对比度 / 伽马 / 模糊 / 锐化 / 自动色阶 / 反相。
- **文字浮雕**：竖排中文（右起竖列）、横排标题、印章；内置《兰亭集序》繁体 / 简体全文与短句模板。
- **照片 + 题字**：上下分区，照片占比、分区间距、留边可调。
- **参数化灯罩**：外径、高度、基础壁厚、最薄 / 最厚、上下边圈、打印精度、55° 悬垂限制。
- **实时预览**：开灯透光、素模浮雕、1:1 展开图三种视图。
- **导出**：二进制 STL 与最小 3MF，在 Web Worker 中生成，不阻塞界面。

## 快速开始

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # 输出 dist/
npm run preview
```

## 设计要点

- 外壁为固定半径 `R` 的光滑圆柱，内壁半径 `R - t`，厚度 `t` 由高度图调制：**亮部薄、暗部厚**。
- 底部开放，可直接罩在 LED 灯板上；上下各留 3 mm 边圈作为结构加强。
- 高度图经过 0.5–4.2 mm 钳制，并按打印层高做 55° 双向斜坡限制，竖直打印无需支撑。
- 网格为水密外壳（外壁 + 内壁 + 上下环盖），三角形数约 `4 × nu × nv`。

## 打印建议

| 项目 | 建议 |
| --- | --- |
| 打印机 | A1 / A1 mini / P1S / X1（默认 Ø140 × 150 mm 在 A1 上可直接打印） |
| 材料 | 白色 PLA（透光最好），100% 实心填充 |
| 喷嘴 / 层高 | 0.4 mm / 0.16–0.20 mm |
| 摆放 | 竖直放置，无需支撑，brim 5 mm |
| 精度 | 默认 0.45 mm；追求细节可用 0.30 mm（约 300 万面），追求速度可用 0.60 mm |

灯罩底部开放，抬起即可操作灯板按键；开灯时灯板朝上放在灯罩内。

## 部署到 GitHub Pages

仓库已包含 `.github/workflows/deploy.yml`。推到 `main` 后：

1. 仓库 **Settings → Pages → Build and deployment → Source** 选择 **GitHub Actions**。
2. 等待 workflow 完成，访问 `https://<用户名>.github.io/<仓库名>/`。

`vite.config.ts` 使用 `base: './'`，兼容项目站点与自定义域名。

## 技术栈

Vite + React + TypeScript + three.js + fflate。字体为 Noto Serif SC 与 Ma Shan Zheng（SIL OFL 1.1）。

## 隐私

所有图片处理、高度图与网格生成均在浏览器本地完成，不上传服务器。导出的 STL / 3MF 由浏览器直接下载。
